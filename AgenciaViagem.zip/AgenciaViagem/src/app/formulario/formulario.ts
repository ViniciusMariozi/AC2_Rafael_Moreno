import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators, AbstractControl, ValidatorFn, ReactiveFormsModule } from '@angular/forms';
import { Subscription } from 'rxjs';
import { debounceTime } from 'rxjs/operators';
import { BrowserModule } from "@angular/platform-browser";

@Component({
  selector: 'formulario',
  standalone: true,
  imports: [ReactiveFormsModule, BrowserModule],
  templateUrl: './formulario.html',
  styleUrls: ['./formulario.css']
})
export class Formulario implements OnInit, OnDestroy {
  formReserva!: FormGroup;
  destinos: string[] = ["Paris", "Nova York", "Tóquio", "Rio de Janeiro"];
  private formSubscription!: Subscription;
  private readonly STORAGE_KEY = 'reservaViagemData';

  constructor(private fb: FormBuilder) { }

  ngOnInit(): void {
    this.construirFormulario();
    this.carregarDadosLocalStorage();
    this.configurarSalvamentoAutomatico();
  }

  construirFormulario(): void {
    this.formReserva = this.fb.group({
      destino: ['', Validators.required],
      dataIda: ['', Validators.required],
      dataVolta: ['', Validators.required],
      numeroPassageiros: [
        1,
        [
          Validators.required,
          Validators.min(1),
          Validators.max(5)
        ]
      ],
      emailContato: [
        '',
        [
          Validators.required,
          Validators.email
        ]
      ]
    });
  }

  carregarDadosLocalStorage(): void {
    const dadosSalvos = localStorage.getItem(this.STORAGE_KEY);
    if (dadosSalvos) {
      const dados = JSON.parse(dadosSalvos);
      this.formReserva.patchValue(dados); 
    }
  }

  configurarSalvamentoAutomatico(): void {
    this.formSubscription = this.formReserva.valueChanges
      .pipe(
        debounceTime(500)
      )
      .subscribe(dados => {
        localStorage.setItem(this.STORAGE_KEY, JSON.stringify(dados));
        console.log('Dados salvos automaticamente no localStorage.');
      });
  }

  get f() {
    return this.formReserva.controls;
  }

  onSubmit(): void {
    if (this.formReserva.valid) {
      console.log('--- Reserva de Viagem Confirmada ---');
      console.log(this.formReserva.value);
      console.log('------------------------------------');

      localStorage.removeItem(this.STORAGE_KEY);
      console.log('Dados removidos do localStorage após submissão.');

      this.formReserva.reset({ numeroPassageiros: 1 });
      this.formReserva.setErrors(null); 

    } else {
      console.error('Formulário inválido. Verifique os campos.');
      this.formReserva.markAllAsTouched();
    }
  }

  ngOnDestroy(): void {
    if (this.formSubscription) {
      this.formSubscription.unsubscribe();
    }
  }
}
